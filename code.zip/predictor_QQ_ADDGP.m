function  y = predictor_QQ_ADDGP(x, dmodel)
%PREDICTOR_QQ_ADDGP  Predictor for y(x) using the proposed additive GP model
% 
% Input
%  x      : trial design sites (for requirements of x, refer to format of 
%          input S in function "dacefit_QQ" 
%  dmodel : Struct with DACE model; "dacefit_QQ_ADDGP"
%
% Output
%  y    : predicted response at x.
%
%  this code is modified based on the code provided by Zhou, Qian, Zhou (2013)

  NQ = dmodel.NQ; % Number of qualitative factors

  [m n] = size(dmodel.S);  % number of design sites and number of dimensions
  sx = size(x);            % number of trial sites and their dimension
  if  min(sx) == 1 & n > 1 % Single trial point 
    nx = max(sx);
    if  nx == n 
      mx = 1;  x = x(:).';
    end
  else
    mx = sx(1);  nx = sx(2);
  end
  if  nx ~= n
    error(sprintf('Dimension of trial sites should be %d',n))
  end

  y = zeros(mx,1);         % initialize result
  
  if  mx == 1  % one site only
    % distances to design sites (based on quantitative factors only)
    dx = repmat(x(1:end-NQ),m,1) - dmodel.S(:,1:end-NQ);
    
    PID(1:m,1:NQ) = repmat(x((end-NQ+1):end),m,1);
    PID(1:m,NQ+1:2*NQ) = dmodel.S(:,(end-NQ+1):end);
    
    f = feval(dmodel.regr, x);
    r = feval(dmodel.cov, dmodel.theta, dx, PID);
    % Predictor
    y = f * dmodel.beta + (dmodel.gamma*r).';
    
  else  % several trial sites
    % Get distances to design sites (based on quantitative factors only)
    dx = zeros(mx*m,n-NQ);  
    kk = 1:m;
    PID = zeros(mx*m,2*NQ); % Initialize PID
    
    for  k = 1 : mx
      dx(kk,:) = repmat(x(k,1:(n-NQ)),m,1) - dmodel.S(:,1:(n-NQ));
      PID(kk,1:NQ) = repmat(x(k,(end-NQ+1):end),m,1);
      PID(kk,(NQ+1):2*NQ) = dmodel.S(:,(end-NQ+1):end);      
      kk = kk + m;
    end
    % Get regression function and correlation
    f = feval(dmodel.regr, x);
    r = feval(dmodel.cov, dmodel.theta, dx,PID);
    r = reshape(r, m, mx);
    
    % predictor 
    y = f * dmodel.beta + (dmodel.gamma * r).'; 
  end
