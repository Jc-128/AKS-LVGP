function  [r, CC] = cov_ADD(theta, d, pid)
% cov_ADD  Additive unrestrictive correlation function for computer models with quantitative
% factors and qualitative factors (this code can handle 1 ~ 7
% qualitative factors each with arbitrary number of levels)
%
% 
% Call:   [r, CC] = cov_ADD(theta, d, pid)
%
% Input
% d      : the component-wise differences between two points (for 
%          quantitative factors only)
% pid    : qualitative factor levels for point pairs
% theta  : variance and correlation parameters. its first part is variance parameters for qualitative factors,
%          its second part contains roughness
%          parameters for the spatial correlation (there are p roughness
%          parameters for each of q qualitative factors, the third part contains
%          parameters for constructing cross-correlation matricess;


% Output
% r      : covariace for each point pair
% CC     : within-factor cross-covariace matrices

[m n] = size(d);  % number of differences and dimension of quantitative factors
t = theta(:)';

Nqt = size(d, 2); % number of quantitative factors
Nql = size(pid, 2)/2; % number of qualitative factors
Nl = max(pid(:, Nql+1:end)); % number of levels for each qualitative factor
Np = Nl.*(Nl-1)/2;  % number of parameters for each qualitative factor

% check number of parameters in theta
if length(theta) ~= (Nql + Nqt*Nql+sum(Np)), error ('incorrect number of parameters'), end

td = zeros([Nql m n]);
for i=1:Nql;
 td(i,:,:) = d.^2 .* repmat(-t((Nql+(i-1)*Nqt+1):(Nql+(i-1)*Nqt+Nqt)),m,1);
end

CC = cell(1, Nql); % initialize output cell containing cross-correlation matrices

switch Nql
    case 1
        CC1 = PD(t(Nql+Nql*Nqt+1 : end));
        CC = CC1;
        SI1 = sub2ind([Nl(1),Nl(1)],pid(:,1),pid(:,2)); %convert row+col index into single index
        td1 = reshape(td(1,:,:),m,n);
        r = t(1)*exp(sum(td1, 2)).*CC1(SI1);
    case 2
        CC1 = PD(t(Nql+Nql*Nqt+1 : Nql+Nql*Nqt+Np(1)));
        CC2 = PD(t(Nql+Nql*Nqt+Np(1)+1 : Nql+Nql*Nqt+Np(1)+Np(2)));
        CC{1} = CC1; CC{2} = CC2;
        SI1 = sub2ind([Nl(1),Nl(1)],pid(:,1),pid(:,3)); 
        SI2 = sub2ind([Nl(2),Nl(2)],pid(:,2),pid(:,4));
        td1 = reshape(td(1,:,:),m,n);
        td2 = reshape(td(2,:,:),m,n);
        r = t(1)*exp(sum(td1, 2)).*CC1(SI1) + t(2)*exp(sum(td2, 2)).*CC2(SI2);      % exp(sum(td, 2)).*CC1(SI1).*CC2(SI2);
    case 3
        CC1 = PD(t(Nql+Nql*Nqt+1 : Nql+Nql*Nqt+Np(1)));
        CC2 = PD(t(Nql+Nql*Nqt+Np(1)+1 : Nql+Nql*Nqt+Np(1)+Np(2)));
        CC3 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+1 : end));
        CC{1} = CC1; CC{2} = CC2; CC{3} = CC3;
        SI1 = sub2ind([Nl(1),Nl(1)],pid(:,1),pid(:,4)); 
        SI2 = sub2ind([Nl(2),Nl(2)],pid(:,2),pid(:,5)); 
        SI3 = sub2ind([Nl(3),Nl(3)],pid(:,3),pid(:,6)); 
        td1 = reshape(td(1,:,:),m,n);
        td2 = reshape(td(2,:,:),m,n);
        td3 = reshape(td(3,:,:),m,n);
        r = t(1)*exp(sum(td1, 2)).*CC1(SI1) + t(2)*exp(sum(td2, 2)).*CC2(SI2)+ t(3)*exp(sum(td3, 2)).*CC3(SI3);
    case 4
        CC1 = PD(t(Nql+Nql*Nqt+1 : Nql+Nql*Nqt+Np(1)));
        CC2 = PD(t(Nql+Nql*Nqt+Np(1)+1 : Nql+Nql*Nqt+Np(1)+Np(2)));
        CC3 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)));
        CC4 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+1 : end));
        CC{1} = CC1; CC{2} = CC2; CC{3} = CC3;CC{4} = CC4;
        SI1 = sub2ind([Nl(1),Nl(1)],pid(:,1),pid(:,5)); 
        SI2 = sub2ind([Nl(2),Nl(2)],pid(:,2),pid(:,6)); 
        SI3 = sub2ind([Nl(3),Nl(3)],pid(:,3),pid(:,7)); 
        SI4 = sub2ind([Nl(4),Nl(4)],pid(:,4),pid(:,8)); 
        td1 = reshape(td(1,:,:),m,n);
        td2 = reshape(td(2,:,:),m,n);
        td3 = reshape(td(3,:,:),m,n);
        td4 = reshape(td(4,:,:),m,n);
        r = t(1)*exp(sum(td1, 2)).*CC1(SI1) + t(2)*exp(sum(td2, 2)).*CC2(SI2)+ t(3)*exp(sum(td3, 2)).*CC3(SI3);
        r = r  + t(4)*exp(sum(td4, 2)).*CC4(SI4);
    case 5
        CC1 = PD(t(Nql+Nql*Nqt+1 : Nql+Nql*Nqt+Np(1)));
        CC2 = PD(t(Nql+Nql*Nqt+Np(1)+1 : Nql+Nql*Nqt+Np(1)+Np(2)));
        CC3 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)));
        CC4 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)));
        CC5 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+1 : end));
        CC{1} = CC1; CC{2} = CC2; CC{3} = CC3;CC{4} = CC4;CC{5} =CC5;
        SI1 = sub2ind([Nl(1),Nl(1)],pid(:,1),pid(:,6)); 
        SI2 = sub2ind([Nl(2),Nl(2)],pid(:,2),pid(:,7)); 
        SI3 = sub2ind([Nl(3),Nl(3)],pid(:,3),pid(:,8)); 
        SI4 = sub2ind([Nl(4),Nl(4)],pid(:,4),pid(:,9)); 
        SI5 = sub2ind([Nl(5),Nl(5)],pid(:,5),pid(:,10)); 
        td1 = reshape(td(1,:,:),m,n);
        td2 = reshape(td(2,:,:),m,n);
        td3 = reshape(td(3,:,:),m,n);
        td4 = reshape(td(4,:,:),m,n);
        td5 = reshape(td(5,:,:),m,n);
        r = t(1)*exp(sum(td1, 2)).*CC1(SI1) + t(2)*exp(sum(td2, 2)).*CC2(SI2)+ t(3)*exp(sum(td3, 2)).*CC3(SI3);
        r = r + t(4)*exp(sum(td4, 2)).*CC4(SI4)+ t(5)*exp(sum(td5, 2)).*CC5(SI5);
    case 6
        CC1 = PD(t(Nql+Nql*Nqt+1 : Nql+Nql*Nqt+Np(1)));
        CC2 = PD(t(Nql+Nql*Nqt+Np(1)+1 : Nql+Nql*Nqt+Np(1)+Np(2)));
        CC3 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)));
        CC4 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)));
        CC5 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+Np(5)));
        CC6 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+Np(5)+1 : end));
        CC{1} = CC1; CC{2} = CC2; CC{3} = CC3;CC{4} = CC4;CC{5} =CC5;CC{6} =CC6;
        SI1 = sub2ind([Nl(1),Nl(1)],pid(:,1),pid(:,7)); 
        SI2 = sub2ind([Nl(2),Nl(2)],pid(:,2),pid(:,8)); 
        SI3 = sub2ind([Nl(3),Nl(3)],pid(:,3),pid(:,9)); 
        SI4 = sub2ind([Nl(4),Nl(4)],pid(:,4),pid(:,10)); 
        SI5 = sub2ind([Nl(5),Nl(5)],pid(:,5),pid(:,11)); 
        SI6 = sub2ind([Nl(6),Nl(6)],pid(:,6),pid(:,12)); 
        td1 = reshape(td(1,:,:),m,n);
        td2 = reshape(td(2,:,:),m,n);
        td3 = reshape(td(3,:,:),m,n);
        td4 = reshape(td(4,:,:),m,n);
        td5 = reshape(td(5,:,:),m,n);
        td6 = reshape(td(6,:,:),m,n);        
        r = t(1)*exp(sum(td1, 2)).*CC1(SI1) + t(2)*exp(sum(td2, 2)).*CC2(SI2)+ t(3)*exp(sum(td3, 2)).*CC3(SI3);
        r = r + t(4)*exp(sum(td4, 2)).*CC4(SI4)+ t(5)*exp(sum(td5, 2)).*CC5(SI5)+ t(6)*exp(sum(td6, 2)).*CC6(SI6);
    case 7
        CC1 = PD(t(Nql+Nql*Nqt+1 : Nql+Nql*Nqt+Np(1)));
        CC2 = PD(t(Nql+Nql*Nqt+Np(1)+1 : Nql+Nql*Nqt+Np(1)+Np(2)));
        CC3 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)));
        CC4 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)));
        CC5 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+Np(5)));
        CC6 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+Np(5)+1 : Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+Np(5)+Np(6)));
        CC7 = PD(t(Nql+Nql*Nqt+Np(1)+Np(2)+Np(3)+Np(4)+Np(5)+Np(6)+1 : end));
        CC{1} = CC1; CC{2} = CC2; CC{3} = CC3;CC{4} = CC4;CC{5} =CC5;CC{6} =CC6;CC{7} =CC7;
        SI1 = sub2ind([Nl(1),Nl(1)],pid(:,1),pid(:,8)); 
        SI2 = sub2ind([Nl(2),Nl(2)],pid(:,2),pid(:,9)); 
        SI3 = sub2ind([Nl(3),Nl(3)],pid(:,3),pid(:,10)); 
        SI4 = sub2ind([Nl(4),Nl(4)],pid(:,4),pid(:,11)); 
        SI5 = sub2ind([Nl(5),Nl(5)],pid(:,5),pid(:,12)); 
        SI6 = sub2ind([Nl(6),Nl(6)],pid(:,6),pid(:,13)); 
        SI7 = sub2ind([Nl(7),Nl(7)],pid(:,7),pid(:,14)); 
        td1 = reshape(td(1,:,:),m,n);
        td2 = reshape(td(2,:,:),m,n);
        td3 = reshape(td(3,:,:),m,n);
        td4 = reshape(td(4,:,:),m,n);
        td5 = reshape(td(5,:,:),m,n);
        td6 = reshape(td(6,:,:),m,n);  
        td7 = reshape(td(7,:,:),m,n);        
        r = t(1)*exp(sum(td1, 2)).*CC1(SI1) + t(2)*exp(sum(td2, 2)).*CC2(SI2)+ t(3)*exp(sum(td3, 2)).*CC3(SI3);
        r = r + t(4)*exp(sum(td4, 2)).*CC4(SI4)+ t(5)*exp(sum(td5, 2)).*CC5(SI5)+ t(6)*exp(sum(td6, 2)).*CC6(SI6)+ t(7)*exp(sum(td7, 2)).*CC7(SI7);

r = r + 1e-8*eye(size(r,1));

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function M = PD(T)
% matrix construction based on hypersphere decomposition
% T:  parameters 

J = ceil(sqrt(2*length(T)));  % number of levels
% if J*(J-1)/2 ~= length(T)  error('Incorrect number of parameters!'), end
L = zeros(J,J); % initialize L matrix

L(1,1) = 1;
L(2,1) = cos(T(1));
L(2,2) = sin(T(1));

for i = 3 : J  % row index in L
    id = (i-1)*(i-2)/2 + 1; % starting parameter for row i
    L(i,1) = cos(T(id));
    for j = 2 : i-1
        k = 1;
        L(i,j) = sin(T(id));
        while k < j-1  L(i,j) = L(i,j)*sin(T(id+k));k = k + 1;end
        L(i,j) = L(i,j)*cos(T(id+j-1));
    end
    L(i,i) = L(i,i-1)/cos(T(id+i-2))*sin(T(id+i-2));
end

M = L * L';


        
        








