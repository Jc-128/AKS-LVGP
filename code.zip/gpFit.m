function model = gpFit(X,y, n_starts, dim_qual, d_lv, levels)

% This function fits the GP model with both qualitative and quantitative variables
% X - a matrix of input data, each row is a sample, qualitative variables
% always stacked to the right of continuous inputs
% y - a vector of response
% n_starts - number of initial guesses for hyperparameters  
% dim_qual - an index array of qualitative variables  
% d_lv - the dimension of latent space, 1 or 2
% returns a matlab structure contains information about the fitted GP model.
% with qualitative variables

if nargin == 6 
    d = size(X,2); % total number of variables   
    n_levels = zeros(length(dim_qual),1); % a vector containing the levels for each qualitative variable 
    for i = 1:length(dim_qual)
        n_levels(i) = length(unique(X(:,dim_qual(i))));  
    end
    
   
    n_lv = d_lv*(sum(n_levels)-length(dim_qual)); % number of latent variables 
    n_quan = d-length(dim_qual); % number of quantitative variables  

     phi0 = zeros(1, n_quan); % initial value of scale parameters for quantitative variables
     z0 =-0.5+rand(1, n_lv); % initial value of latent variables 把-0.5改成0.5试试
      params0 = [phi0, z0]; % complete initial parameter set 
%         
    if d_lv ==1
        
        lb = -2*ones(1, n_quan); 
        ub = 2*ones(1, n_quan);
        for i = 1:length(dim_qual)
            lb = [lb, -3, -2*ones(1, n_levels(i)-2)];   % lower bound
            ub = [ub, 3, 2*ones(1, n_levels(i)-2)];    % upper bound
        end
    elseif d_lv==2
        
        lb = -2*ones(1, n_quan); 
        ub = 2*ones(1, n_quan);
        for i = 1:length(dim_qual)
            lb = [lb, -2, 0, -2*ones(1, 2*n_levels(i)-4)]; % lower bound
            ub = [ub, 2, 0, 2*ones(1, 2*n_levels(i)-4)]; % upper bound       
        end
        
    end
    
    % create optimization problem to maximize loglikelihood, with 100 random initial points
     options=optimoptions('fmincon','SpecifyObjectiveGradient',false);
     problem = createOptimProblem('fmincon',...
         'objective',@(params)logLikelihood(params,X,y,dim_qual,d_lv,levels),...
         'x0',params0, 'lb', lb, 'ub', ub, 'options', options);
     ms = MultiStart;
     [params_star,f] = run(ms,problem,n_starts);


    model.X = X; 
    model.y = y; 
    model.n_starts = n_starts;
    model.dim_qual = dim_qual; 
    model.d_lv = d_lv; 
    model.levels = levels;
    model.phi = params_star(1:n_quan); 
    model.z = params_star(n_quan+1:n_quan+n_lv); 
    model.logL = f;
    

% without qualitative variables
elseif nargin == 3 
    d = size(X,2);
    phi0 = zeros(1, d);
    lb = -2*ones(1,d); ub = 2*ones(1,d);
    
    options = optimoptions('fmincon','SpecifyObjectiveGradient',false);
    problem = createOptimProblem('fmincon',...
        'objective',@(params)logLikelihood(params,X,y),...
        'x0',phi0, 'lb', lb, 'ub', ub, 'options', options);
    ms = MultiStart('UseParallel', false);
    [params_star, f] = run(ms,problem,n_starts);
    
    model.X = X; model.y = y; model.n_starts = n_starts;
    model.phi = params_star; model.logL = f;
end