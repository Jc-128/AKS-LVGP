
addpath(genpath([pwd '\dataset']));
XY=xlsread('DATA6.xlsx');
XZ=XY(1:100,1:2);
y=XY(1:100,3);

x_pred=XY(101:120,1:2);
y_true=XY(101:120,3);
 

addpath(genpath([pwd '\gpml']));

d = 2; % number of input variables          
d_quan = 1; % number of quantitative variables     
d_qual = 1; % number of qualitative variables        


dim_qual = [2]; % dimension of qualitative variables

d_lv = 2; % set the dimension of latent variable to be 2   
levels = [4]; % levels of the qualitative variable in this example    

n_starts = 200; % number of initial points of hyperparameters   

%% fit Latent Variable model  
model_LV = gpFit(XZ,y, n_starts, dim_qual, d_lv, levels);
y_LV = gpPredict(model_LV, x_pred);

%% fit MC model
X_MC = [XZ(:,1:min(dim_qual)-1),dummyvar(XZ(:,dim_qual))]; 
x_pred_MC = [x_pred(:,1:min(dim_qual)-1),dummyvar(x_pred(:,dim_qual))];
model_MC = gpFit(X_MC, y, n_starts);
y_MC = gpPredict(model_MC, x_pred_MC);

%% fit UC model
X_UC = toIndicator(XZ, dim_qual); 
x_pred_UC = toIndicator(x_pred, dim_qual);
model_UC = gpFit(X_UC, y, n_starts);
y_UC = gpPredict(model_UC, x_pred_UC);

%% fit Add_UC model
[modelADD, y_add] = UCADDGP(XZ, y, d_quan, d_qual, levels, x_pred);

%% compare rrmse
rrmse_LV = sqrt(mean((y_LV-y_true).^2)/var(y_true));
rrmse_MC = sqrt(mean((y_MC-y_true).^2)/var(y_true));
rrmse_UC = sqrt(mean((y_UC-y_true).^2)/var(y_true));
rrmse_add = sqrt(mean((y_add-y_true).^2)/var(y_true));

%% plot 2D latent variables
plotLatent2D(model_LV);