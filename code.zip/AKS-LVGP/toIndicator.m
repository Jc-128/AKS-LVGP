function W = toIndicator(X, dim_qual)
% This function transforms categorical dimensions into indicators W,
% used for fitting the Unrestrictive Covariance (UC) model

[n, d] = size(X);
d_qual = length(dim_qual);
X_quan = X(:,1: d-d_qual);

X_qual = X(:,dim_qual);


W = [];
for i = 1:d_qual
    I = dummyvar(X_qual(:,i));
    T = size(I,2);

    for p = 1:T
        for q = 1:T
            if p == q
                w(:, (p-1)*T + q) = I(:,p);
            else
                w(:, (p-1)*T + q) = I(:,p) + I(:,q);
            end
        end
    end

    W = [W w];
end
W = [X_quan W];