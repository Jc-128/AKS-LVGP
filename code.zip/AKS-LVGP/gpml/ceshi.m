XZ=xlsread('trainingXZ.xlsx');  
y=xlsread('trainingsetY.xlsx');

x_pred=xlsread('testsetXZ.xlsx');
y_true=xlsread('testsetY.xlsx');
addpath(genpath([pwd '\gpml']));
[nlZ dnlZ          ] = gp([0.1,0.2], infGaussLik, meanZero, covSE,likGauss, XZ, y);