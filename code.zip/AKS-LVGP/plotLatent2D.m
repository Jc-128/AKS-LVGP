function plotLatent2D(model)

m = model.levels;
X_latent = model.z{3};

mm = m-1;

for j = 1:length(mm)
        figure(j);
        hold on;
        if j > 1
       
            x_plot = [0 X_latent(2*sum(mm(1:j-1))+1:2:2*sum(mm(1:j))-1)];
            y_plot = [0 X_latent(2*sum(mm(1:j-1))+2:2:2*sum(mm(1:j)))];
    
            scatter(x_plot,y_plot);
            
            for k = 1:m(j)
                text(x_plot(k),y_plot(k) + 0.05*range(x_plot), num2str(k));
            end
            
        else
            x_plot = [0 X_latent(1:2:2*sum(mm(1:j))-1)];
            y_plot = [0 X_latent(2:2:2*sum(mm(1:j)))];
            scatter(x_plot,y_plot);
            
            for k = 1:m(j)
                text(x_plot(k),y_plot(k) + 0.05*range(x_plot), num2str(k));
            end
            
        end
        
        hold off;
        axis equal;
        title(['Latent space of factor ' num2str(j)]);
        xlabel('z_1'); ylabel('z_2');
end