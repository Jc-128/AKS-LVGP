function [modelUCADD,PFUCADD] = UCADDGP(XT, F, p, q, m, PX)

options = optimset('Display','off');
IT(1:p) = rand(1,p)*10;
IT_ADD = [ ones(1,q)*std(F)/q  repmat(IT(1:p),1,q) ones(1,sum(m.*(m-1)/2))];
LB_ADD = [ones(1,q)*0.001*var(F) ones(1,p*q+sum(m.*(m-1)/2))*0.1];
UB_ADD = [ones(1,q)*var(F) ones(1,p*q)*20  (pi-0.01)*ones(1,sum(m.*(m-1)/2))]; 


[modelUCADD, perfUCADD] = dacefit_QQ_ADDGP(XT, F, q, @regpoly0, @cov_ADD, IT_ADD, LB_ADD, UB_ADD, 'fmincon', options);

PFUCADD = predictor_QQ_ADDGP(PX, modelUCADD);