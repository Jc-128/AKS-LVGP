function  [dmodel,perform] = dacefit_QQ_ADDGP(S, Y, NQ, regr, cov, theta0, lob, upb, varargin)
% DACEFIT_QQ_ADDGP Emulation program for computer models with quantitative
% factors and qualitative factors 
%     the function can handle 1 ~ 7  qualitative factors each with arbitrary number of levels)
% 
%
% Input
% S, Y    : Data points (S(i,:), Y(i,:)), i = 1,...,m. For input sites S 
%           with both quantitative and qualitative factors, qualitative
%           variables should be listed after quantitative variables. For
%           example, if there are 4 quantitative factors and 3 qualitative
%           factor, then S=[X1,X2,X3,X4,Z1,Z2,Z3]. The levels of qualitative
%           factors should be labeled as "1,2,3,...", and each level should
%           appear at least once in the design sites. The quantitative
%           variables and response variable should be normalized (if needed)
%           prior to using dacefit_QQ. 
% NQ      : Number of qualitative factors
% regr    : Function handle to a regression model
% cov     : Function handle to a covariance function
% theta0  : Initial guess on theta,the variance parameters and the correlation function parameters
% lob,upb : If present, then lower and upper bounds on theta, and a search algorithm must specified.
%           Otherwise, theta0 is used for theta and no optimization will be done
%'SearchAlgorithm': currently two search methods are available, choose any one:
%           (1)'fmincon' (with multiple choice of search algorithms, see matlab help for details)
%           (2)'dace' (a patterns search method originally provided in DACE package)
% options : optional parameter set to pass to 'fmincon' (see matlab help for details)
%           The default search algorithm is set to 'interior-point' if
%           options is not specified for 'fmincon' by the user
%
% Output
% dmodel  : DACE model: a struct with the elements
%    regr   : function handle to the regression model
%    cov    : function handle to the covariance function
%    theta  : variance parameters and correlation function parameters
%    beta   : generalized least squares estimate    广义最小二乘估计
%    gamma  : correlation factors
%    sigma2 : maximum likelihood estimate of the process variance
%    S      : design sites (if needed, normalize prior to using this function)
%    C      : Cholesky factor of correlation matrix
%    CCx    : within-factor cross-correlation matrix for qualitative factors
%    Ft     : Decorrelated regression matrix
%    G      : From QR factorization: Ft = Q*G' .
% perform   : struct with performance information returned by the search algorithm. 
%             For 'fmincon', see its 'output' in matlab help. For 'dace', the elements are
%    nv     : Number of evaluations of objective function
%    perf   : (q+2)*nv array, where q is the number of elements 
%             in theta, and the columns hold current values of
%                 [theta;  psi(theta);  type]
%             |type| = 1, 2 or 3, indicate 'start', 'explore' or 'move'
%             A negative value for type indicates an uphill step


% check inputs
lth = length(theta0);
if nargin > 6 && isempty(varargin)
    error('A search algorithm must be specified for the optimization')
elseif nargin > 6 && ~isempty(varargin)
    if  length(lob) ~= lth || length(upb) ~= lth
      error('theta0, lob and upb must have the same length'), end
    if  any(lob <= 0) || any(upb < lob)
      error('The bounds must satisfy  0 < lob <= upb'), end    
    if strcmpi(varargin{1}, 'fmincon')
        SA = 1; % search algorithm is 'fmincon'
        if length(varargin) == 2
           options = varargin{2}; % options are specified and will be passed to 'fmincon'
        end
    end
elseif nargin == 6  % given theta
    if  any(theta0 <= 0)
    error('theta0 must be strictly positive'), end
else
    error('insufficient number of inputs')
end    

% Check design points
[m n] = size(S);  % number of design sites and their dimension
sY = size(Y);
if  min(sY) == 1,  Y = Y(:);   lY = max(sY);  sY = size(Y);
else lY = sY(1); end
if m ~= lY
  error('S and Y must have the same number of rows'), end

% Calculate distances D between points (based on quantitative inputs only)
mzmax = m*(m-1) / 2;        % number of non-zero distances
ij = zeros(mzmax, 2);       % initialize matrix with indices
D = zeros(mzmax, n-NQ);        % initialize matrix with distances 
PID = zeros(mzmax, NQ*2);       % initialize matrix storing qualitative 
                                % factor levels
ll = 0;
for k = 1 : m-1
  ll = ll(end) + (1 : m-k);
  ij(ll,:) = [repmat(k, m-k, 1) (k+1 : m)']; % indices for sparse matrix
  % pairwise point distances(based only on quantitative factors)
  D(ll,:) = repmat(S(k,1:end-NQ), m-k, 1) - S(k+1:m,1:end-NQ); 
  % qualitative factor levels of the 1st point in the pair
  PID(ll,1:NQ) = repmat(S(k,(end-NQ+1):end), m-k, 1);
  % qualitative factor levels of the 2nd point in the pair
  PID(ll,NQ+1:2*NQ) = S(k+1:m,(end-NQ+1):end);
end

Sm = 0;SD = 0;Sij = 0;

% Regression matrix
F = feval(regr, S);  [mF p] = size(F);
if  mF ~= m, error('number of rows in  F  and  S  do not match'), end
if  p > mF,  error('least squares problem is underdetermined'), end

% parameters for objective function
par = struct('cov',cov, 'regr',regr, 'y',Y, 'F',F, ...
  'D', D, 'ij',ij, 'PID',PID, 'SD',SD,'Sij',Sij,'Sm',Sm);

% Determine theta
if nargin > 6 && SA == 1
    % search algorithm in matlab 'fmincon'
    if length(varargin) == 1
        optionsdflt = optimset('Algorithm','interior-point','Display','off');
        [theta f fit output] = mleparam(theta0, lob, upb, par, optionsdflt);
    elseif length(varargin) == 2
            [theta f fit output] = mleparam(theta0, lob, upb, par, options);
    end
    if  isinf(f)
    error('Bad parameter region.  Try increasing  upb'), end
else
  % Given theta
  theta = theta0(:);   
  [f  fit] = objfunc(theta, par);
  perf = struct('perf',[theta; f; 1], 'nv',1);
  if  isinf(f)
    error('Bad point.  Try increasing theta0'), end
end

% Return values
switch NQ
    case 1
    dmodel = struct('regr',regr, 'cov',cov, 'theta',theta.', ...
      'beta',fit.beta, 'gamma',fit.gamma,'sigma2',fit.sigma2, ...
      'S',S, 'C',fit.C, 'Ft',fit.Ft, 'G',fit.G, 'NQ', NQ, ...
      'CC1',fit.CC1);
   case 2
    dmodel = struct('regr',regr, 'cov',cov, 'theta',theta.', ...
      'beta',fit.beta, 'gamma',fit.gamma,'sigma2',fit.sigma2, ...
      'S',S, 'C',fit.C, 'Ft',fit.Ft, 'G',fit.G, 'NQ', NQ, ...
      'CC1',fit.CC1, 'CC2',fit.CC2);
   case 3
    dmodel = struct('regr',regr, 'cov',cov, 'theta',theta.', ...
      'beta',fit.beta, 'gamma',fit.gamma,'sigma2',fit.sigma2, ...
      'S',S, 'C',fit.C, 'Ft',fit.Ft, 'G',fit.G, 'NQ', NQ, ...
      'CC1',fit.CC1, 'CC2',fit.CC2, 'CC3',fit.CC3);
   case 4 
    dmodel = struct('regr',regr, 'cov',cov, 'theta',theta.', ...
     'beta',fit.beta, 'gamma',fit.gamma,'sigma2',fit.sigma2, ...
     'S',S, 'C',fit.C, 'Ft',fit.Ft, 'G',fit.G, 'NQ', NQ, ...
     'CC1',fit.CC1, 'CC2',fit.CC2, 'CC3',fit.CC3,'CC4',fit.CC4);
   case 5
    dmodel = struct('regr',regr, 'cov',cov, 'theta',theta.', ...
     'beta',fit.beta, 'gamma',fit.gamma,'sigma2',fit.sigma2, ...
     'S',S, 'C',fit.C, 'Ft',fit.Ft, 'G',fit.G, 'NQ', NQ, ...
     'CC1',fit.CC1, 'CC2',fit.CC2, 'CC3',fit.CC3,'CC4',fit.CC4,'CC5',fit.CC5);
   case 6
    dmodel = struct('regr',regr, 'cov',cov, 'theta',theta.', ...
     'beta',fit.beta, 'gamma',fit.gamma,'sigma2',fit.sigma2, ...
     'S',S, 'C',fit.C, 'Ft',fit.Ft, 'G',fit.G, 'NQ', NQ, ...
     'CC1',fit.CC1, 'CC2',fit.CC2, 'CC3',fit.CC3,'CC4',fit.CC4,'CC5',fit.CC5,'CC6',fit.CC6);
    case 7
    dmodel = struct('regr',regr, 'cov',cov, 'theta',theta.', ...
     'beta',fit.beta, 'gamma',fit.gamma,'sigma2',fit.sigma2, ...
     'S',S, 'C',fit.C, 'Ft',fit.Ft, 'G',fit.G, 'NQ', NQ, ...
     'CC1',fit.CC1, 'CC2',fit.CC2, 'CC3',fit.CC3,'CC4',fit.CC4,'CC5',fit.CC5,'CC6',fit.CC6,'CC7',fit.CC7);
end
if nargout > 1 && SA == 0
    perform = perf;
elseif nargout > 1 && SA == 1
    perform = output;
end
    

% >>>>>>>>>>>>>>>>   Auxiliary functions  ====================
function  [obj, fit] = objfunc(theta, par)
% Initialize
obj = inf; 
fit = struct('sigma2',NaN, 'beta',NaN, 'gamma',NaN, ...
    'C',NaN, 'Ft',NaN, 'G',NaN);
m = size(par.F,1);
%Set up  R
[r, CC] = feval(par.cov, theta, par.D, par.PID);
idx = 1:length(r);
o = (1 : m)';   
mu = (10+m)*eps;

R = ones(m,m)*sum(theta(1:(size(par.PID,2)/2)));
jj = 1;
for i=1:(m-1)
  for j=(i+1):m
     R(i,j) = r(jj);
     R(j,i) = R(i,j);
     jj = jj + 1;
  end
end

%R = sparse([par.ij(idx,1); o], [par.ij(idx,2); o], ...
%  [r(idx); ones(m,1)+mu]);  
% Cholesky factorization with check for pos. def.
% R= corrcov(R);  % covert from covariance matrix to correlation matrix
[C rd] = chol(R);
if  rd,  return, end % not positive definite

% Get least squares solution
C = C';   Ft = C \ par.F;
[Q G] = qr(Ft,0);
if  rcond(G) < 1e-10
  % Check   F  
  if  cond(par.F) > 1e15 
    T = sprintf('F is too ill conditioned\nPoor combination of regression model and design sites');
    error(T)
  else  % Matrix  Ft  is too ill conditioned
    return 
  end 
end
Yt = C \ par.y;   beta = G \ (Q'*Yt);
rho = Yt - Ft*beta; sigma2 = R(1,1); % sigma2 = sum(rho.^2)/m;
gamma = rho' / C;
obj =    sum(log(full(diag(R)))) + sum(rho.^2); 

Nql = size(par.PID, 2)/2; % number of qualitative factors

switch Nql
    case 1
        CC1 = CC; CC2 = []; CC3 = [];
    case 2
        CC1 = CC{1}; CC2 = CC{2}; CC3 = [];
    case 3
        CC1 = CC{1}; CC2 = CC{2}; CC3 = CC{3};
    case 4
        CC1 = CC{1}; CC2 = CC{2}; CC3 = CC{3};CC4 = CC{4};
    case 5
        CC1 = CC{1}; CC2 = CC{2}; CC3 = CC{3};CC4 = CC{4};CC5= CC{5};
    case 6        
       CC1 = CC{1}; CC2 = CC{2}; CC3 = CC{3};CC4 = CC{4};CC5= CC{5};CC6= CC{6};
    case 7       
       CC1 = CC{1}; CC2 = CC{2}; CC3 = CC{3};CC4 = CC{4};CC5= CC{5};CC6= CC{6};CC7= CC{7};
end
if  nargout > 1
 switch Nql
    case 1
      fit = struct('sigma2',sigma2,'beta',beta, 'gamma',gamma, ...
        'C',C, 'Ft',Ft, 'G',G', 'CC1',CC1);
    case 2
      fit = struct('sigma2',sigma2,'beta',beta, 'gamma',gamma, ...
        'C',C, 'Ft',Ft, 'G',G', 'CC1',CC1, 'CC2',CC2);
    case 3
      fit = struct('sigma2',sigma2,'beta',beta, 'gamma',gamma, ...
        'C',C, 'Ft',Ft, 'G',G', 'CC1',CC1, 'CC2',CC2, 'CC3',CC3);
    case 4
      fit = struct('sigma2',sigma2,'beta',beta, 'gamma',gamma, ...
        'C',C, 'Ft',Ft, 'G',G', 'CC1',CC1, 'CC2',CC2, 'CC3',CC3,'CC4',CC4);
    case 5
      fit = struct('sigma2',sigma2,'beta',beta, 'gamma',gamma, ...
        'C',C, 'Ft',Ft, 'G',G', 'CC1',CC1, 'CC2',CC2, 'CC3',CC3,'CC4',CC4,'CC5',CC5);
    case 6        
      fit = struct('sigma2',sigma2,'beta',beta, 'gamma',gamma, ...
        'C',C, 'Ft',Ft, 'G',G', 'CC1',CC1, 'CC2',CC2, 'CC3',CC3,'CC4',CC4,'CC5',CC5,'CC6',CC6);
    case 7    
      fit = struct('sigma2',sigma2,'beta',beta, 'gamma',gamma, ...
        'C',C, 'Ft',Ft, 'G',G', 'CC1',CC1, 'CC2',CC2, 'CC3',CC3,'CC4',CC4,'CC5',CC5,'CC6',CC6,'CC7',CC7);
 end
end

%--------------------------------------------------------

function [theta, fmin, fit, output] = mleparam(theta0, lo, up, par, options)
% Matlab Optimization Toolbox is needed to use "fmincon"
ofun = @(theta)objfunc(theta,par);
problem = createOptimProblem('fmincon',...
        'objective',ofun,...
        'x0',theta0, 'lb', lo, 'ub', up, 'options', options);
ms = MultiStart('UseParallel', true);
[theta,fmin, exitflag, output] = run(ms,problem,200);
%display(theta); display(fmin);
[f, fit] = objfunc(theta, par);
